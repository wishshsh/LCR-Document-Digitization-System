// =============================================================
//  js/globals.js — Shared state, loaded FIRST before all others
// =============================================================

// Global variables
let uploadedFiles = {
    cert: [],
    marriage: []
};

let records = [
    { id: 'BC-001', type: 'birth', name: 'Maria Santos', date: '2025-01-10', status: 'Approved' },
    { id: 'BC-002', type: 'birth', name: 'Jose Reyes', date: '2025-01-15', status: 'Pending' },
    { id: 'BC-003', type: 'birth', name: 'Ana Dela Cruz', date: '2025-02-03', status: 'Pending' },
    { id: 'DC-001', type: 'death', name: 'Roberto Villanueva', date: '2025-02-14', status: 'Approved' },
    { id: 'DC-002', type: 'death', name: 'Lourdes Magno', date: '2025-03-01', status: 'Rejected' },
    { id: 'MC-001', type: 'marriage-cert', name: 'Carlos & Elena Bautista', date: '2025-01-28', status: 'Approved' },
    { id: 'MC-002', type: 'marriage-cert', name: 'Ramon & Sofia Dizon', date: '2025-02-20', status: 'Pending' },
    { id: 'ML-001', type: 'marriage-license', name: 'Paolo & Kristine Mendoza', date: '2025-03-05', status: 'Pending' },
    { id: 'ML-002', type: 'marriage-license', name: 'Angelo & Camille Torres', date: '2025-03-06', status: 'Approved' },
    { id: 'BC-004', type: 'birth', name: 'Gabrielle Ramos', date: '2025-03-07', status: 'Pending' }
];

// Navigation history
let navigationHistory = ['login'];
let currentHistoryIndex = 0;
let isLoggedIn = false;

// User data
let currentUser = {
    username: '',
    name: 'Admin User',
    email: 'admin@localregistry.gov.ph',
    role: 'Administrator',
    department: 'Civil Registry Office',
    employeeId: 'EMP-2024-001'
};

// Page URLs mapping (for potential future use)
const pageUrls = {
    'login': 'https://localcivilregistry.gov.ph',
    'services': 'https://localcivilregistry.gov.ph/services',
    'certifications': 'https://localcivilregistry.gov.ph/services/certifications',
    'certTemplateView': 'https://localcivilregistry.gov.ph/services/certifications/template',
    'marriageLicense': 'https://localcivilregistry.gov.ph/services/marriage-license',
    'marriageTemplateView': 'https://localcivilregistry.gov.ph/services/marriage-license/template',
    'records': 'https://localcivilregistry.gov.ph/records',
    'profile': 'https://localcivilregistry.gov.ph/profile'
};

// Update back button visibility
